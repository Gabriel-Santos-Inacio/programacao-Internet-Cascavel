let paozinho = document.querySelector("#paozinho");
let broa = document.querySelector("#broa");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcularFaturamento(){

    let paes = Number(paozinho.value);
    let broas = Number(broa.value);
    let valorPao = 0.12;
    let valorBroa = 1.50;
    let vendaDia = paes*valorPao + broas*valorBroa;
    let poupanca = vendaDia*0.10;
    resultado.textContent = " o valor total de vendas foi: " + vendaDia + " reais. desse valor voce ira quardar: " + poupanca + " reais na poupanca";

}

btCalcular.onclick = calcularFaturamento;