let quantidade = document.querySelector("#quantidade");
let btCalcular = document.querySelector("#btCalcular");
let resultadoDeFerraduras = document.querySelector("#resultadoDeFerraduras");

function calcularFerraduras(){

    let cavalos = Number(quantidade.value);

    let ferraduras = 4;

    let calculo = cavalos * ferraduras;

    resultadoDeFerraduras.textContent = "Voce ira precisar de: " + calculo + " ferraduras";
}

btCalcular.onclick = calcularFerraduras;