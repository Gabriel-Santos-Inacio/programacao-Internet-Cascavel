let nome = document.querySelector("#nome");
let idade = document.querySelector("#idade");
let diasVividos = document.querySelector("#diasVividos");
let btResolucao = document.querySelector("#btResolucao");

function calcularDias(){

    let nomePessoa = nome.value;
    let anos = Number(idade.value);
    let anoDias = 365;
    let resultado = anos * anoDias;
    
    diasVividos.textContent = nomePessoa + " voce tem " + resultado + " dias vividos. ";

}

btResolucao.onclick = calcularDias;