    let h1Texto = document.querySelector("#h1Texto");
    let inputTexto = document.querySelector("#inputTexto");
    let btTrocaTexto = document.querySelector("#btTrocaTexto");

    function trocarTexto(){
        // Retornando o texto digitando no campo
        let textoDigitado = inputTexto.value;

        // Alterando o texto do elemento
        h1Texto.textContent = textoDigitado;
    }

    btTrocaTexto.onclick = function(){
        trocarTexto();
    }