let h1texto = document.querySelector("#h1texto");
let inputPrimeiroNumero = document.querySelector("#inputPrimeiroNumero");
let inputSegundoNumero = document.querySelector("#inputSegundoNumero");
const botaozudo = document.querySelector("#btresolucao")

function ResolverProblema(){
    let num = Number(inputPrimeiroNumero.value) - Number(inputSegundoNumero.value);
    console.log(num);
    h1texto.textContent = num;
}

botaozudo.onclick = function(){
    ResolverProblema()
}