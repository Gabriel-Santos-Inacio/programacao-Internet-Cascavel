let nota1Bim = document.querySelector("#nota1Bim");
let noat2Bim = document.querySelector("#nota2Bim");
let btaprovacao = document.querySelector("#btaprovacao");
let h3resultado = document.querySelector("#h3resultado");

function calcularMediaAluno(){

//retornado vlaores dos inputs e
//convertendo em números 
let nota1 = Number(nota1Bim.value);
let nota2 = Number(nota2Bim.value);

//Calcular média
let media = (nota1+nota2) / 2;

//Verificar se o alino esta aprovado ou não
if(media>= 60){
    h3resultado.textContent ="O aluno esta APROVADO!!!";
}else{
    h3resultado.textContent ="O aluno esta REPROVADO!!!";
}

}

btaprovacao.onclick = function(){
    calcularMediaAluno();
}