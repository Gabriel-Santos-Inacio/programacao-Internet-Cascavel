let resultado = document.querySelector("#resultado1");
let valorDoProduto = document.querySelector("#valorDoProduto");
let valorPago = document.querySelector("#valorPago");
const botaozudo = document.querySelector("#btresolucao")

function ResolverProblema(){
    let num = Number(valorDoProduto.value) - Number(valorPago.value);
    console.log(num);
    resultado.textContent = "Troco: "+num;
}

botaozudo.onclick = function(){
    ResolverProblema()
}