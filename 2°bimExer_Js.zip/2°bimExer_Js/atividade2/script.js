let resultado = document.querySelector("#resultado1");
let valorDoKg = document.querySelector("#valorDoKg");
let valorPagoKg = document.querySelector("#valorPagoKg");
const botaozudo = document.querySelector("#btresolucao");

function ResolverProblema(){
    let num = Number(valorDoKg.value) * Number(valorPagoKg.value);
    console.log(num);
    resultado.textContent = "Valor a Pagar: "+num;
}

botaozudo.onclick = function(){
    ResolverProblema()
}