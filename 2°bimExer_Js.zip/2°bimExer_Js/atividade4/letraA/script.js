let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let valor3 = document.querySelector("#valor3");
const btresolucao = document.querySelector("#btresolucao");

function media(){
    let num = Number(valor1.value) + Number(valor2.value) + Number(valor3.value);
}