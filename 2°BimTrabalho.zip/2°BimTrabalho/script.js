function verificarTriangulo(){

    let x = parseFloat(document.getElementById('x').value);
    let y = parseFloat(document.getElementById('y').value);
    let z = parseFloat(document.getElementById('z').value);

    let resultado = document.getElementById('resultado-triangulo');

    if (x < y + z && y < x +z && z < x + y){
        if (x === y && y === z) {
            resultado.textContent = "Triângulo Equilátero";
        } else if (x === y || y === z || x === z){
            resultado.textContent = "Triângulo Isóceles";
        } else {
            resultado.textContent = "Triângulo Escaleno";
        }
    } else {
        resultado.textContent = "Não formam um triângulo!"
    }
}


function calcularIMC(){

    const peso = parseFloat(document.getElementById('peso').value);
    const altura = parseFloat(document.getElementById('altura').value);

    if (isNaN(peso) || isNaN(altura) || altura <=0) {
        document.getElementById("resultado").textContent = "Por favor insira valores validos!"
        return
    }

    const imc = peso / (altura * altura);

    let classificacao = "";
    if (imc < 18.5) {
        classificacao = "Abaiso do peso";
    } else if (imc < 25) {
        classificacao = "Peso normal";
    } else if (imc < 30){
        classificacao = "Sobrepeso";
    } else if (imc < 35) {
        classificacao = "Obesidade garu 1"
    } else if (imc < 40) {
        classificacao = "Obesidade grau 2"
    } else {
        classificacao = "Obesidade grau 3"
    }

    document.getElementById("resultado").textContent = `Seu IMC é ${imc.toFixed(2)} (${classificacao})`;
}


function calcularImposto(){

    const ano = parseInt(document.getElementById('anoCarro').value);
    const valor = parseFloat(document.getElementById('valorCarro').value);

    let imposto;
}

