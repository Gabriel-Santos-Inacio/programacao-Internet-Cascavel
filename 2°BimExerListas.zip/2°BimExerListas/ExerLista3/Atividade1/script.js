let largura = document.querySelector("#largura");
let altura = document.querySelector("#altura");
let btCalcularArea = document.querySelector("#btCalcularArea");
let resultado = document.querySelector("#resultado");

function calcular(){
    let valor1 = Number(largura.value);
    let valor2 = Number(altura.value);
    let resolucao = valor1 * valor2;

    resultado.textContent = resolucao;
}

btCalcularArea.onclick = calcular;