function ex1() {
  const largura = parseFloat(document.getElementById("largura1").value);
  const comprimento = parseFloat(document.getElementById("comprimento1").value);
  const area = largura * comprimento;
  document.getElementById("resultado1").innerText = `Área: ${area.toFixed(2)} m²`;
}

function ex2() {
  const cavalos = parseInt(document.getElementById("cavalos2").value);
  document.getElementById("resultado2").innerText = `Ferraduras necessárias: ${cavalos * 4}`;
}

function ex3() {
  const paes = parseInt(document.getElementById("paes3").value);
  const broas = parseInt(document.getElementById("broas3").value);
  const total = (paes * 0.12) + (broas * 1.5);
  const poupanca = total * 0.1;
  document.getElementById("resultado3").innerText = `Total: R$ ${total.toFixed(2)} | Poupança: R$ ${poupanca.toFixed(2)}`;
}

function ex4() {
  const nome = document.getElementById("nome4").value;
  const idade = parseInt(document.getElementById("idade4").value);
  const dias = idade * 365;
  document.getElementById("resultado4").innerText = `${nome.toUpperCase()}, VOCÊ JÁ VIVEU ${dias} DIAS.`;
}

function ex5() {
  const preco = parseFloat(document.getElementById("preco5").value);
  const valor = parseFloat(document.getElementById("valor5").value);
  const litros = valor / preco;
  document.getElementById("resultado5").innerText = `Você colocou ${litros.toFixed(2)} litros.`;
}

function ex6() {
  const peso = parseFloat(document.getElementById("peso6").value);
  const preco = peso * 12;
  document.getElementById("resultado6").innerText = `Valor a pagar: R$ ${preco.toFixed(2)}`;
}

function ex7() {
  const dia = parseInt(document.getElementById("dia7").value);
  const mes = parseInt(document.getElementById("mes7").value);
  const dias = (mes - 1) * 30 + dia;
  document.getElementById("resultado7").innerText = `${dias} dias se passaram desde o início do ano.`;
}

function ex8() {
  const p = parseInt(document.getElementById("p8").value);
  const m = parseInt(document.getElementById("m8").value);
  const g = parseInt(document.getElementById("g8").value);
  const total = p * 10 + m * 12 + g * 15;
  document.getElementById("resultado8").innerText = `Total arrecadado: R$ ${total.toFixed(2)}`;
}

function ex9() {
  const x1 = parseFloat(document.getElementById("x1_9").value);
  const y1 = parseFloat(document.getElementById("y1_9").value);
  const x2 = parseFloat(document.getElementById("x2_9").value);
  const y2 = parseFloat(document.getElementById("y2_9").value);
  const dist = Math.hypot(x2 - x1, y2 - y1);
  document.getElementById("resultado9").innerText = `Distância: ${dist.toFixed(2)}`;
}

function ex10() {
  const dias = parseInt(document.getElementById("dias10").value);
  const anos = Math.floor(dias / 360);
  const meses = Math.floor((dias % 360) / 30);
  const diasRest = dias % 30;
  document.getElementById("resultado10").innerText = `${anos} ano(s), ${meses} mês(es), ${diasRest} dia(s)`;
}

function ex11() {
  const salario = parseFloat(document.getElementById("salario11").value);
  const aumento = salario * 1.15;
  const final = aumento * 0.92;
  document.getElementById("resultado11").innerText =
    `Salário inicial: R$${salario.toFixed(2)} | Aumento: R$${aumento.toFixed(2)} | Final: R$${final.toFixed(2)}`;
}

function ex12() {
  let numero = parseInt(document.getElementById("num12").value);
  const centena = Math.floor(numero / 100);
  const dezena = Math.floor((numero % 100) / 10);
  const unidade = numero % 10;
  document.getElementById("resultado12").innerText = `CENTENA = ${centena} | DEZENA = ${dezena} | UNIDADE = ${unidade}`;
}

function ex13() {
  const raio = parseFloat(document.getElementById("raio13").value);
  const area = 3.14 * raio * raio;
  document.getElementById("resultado13").innerText = `Área da pizza: ${area.toFixed(2)} m²`;
}

function ex14() {
  const total = parseFloat(document.getElementById("valor14").value);
  const carlos = Math.floor(total / 3);
  const andre = carlos;
  const felipe = total - carlos - andre;
  document.getElementById("resultado14").innerText =
    `Carlos: R$${carlos.toFixed(2)} | André: R$${andre.toFixed(2)} | Felipe: R$${felipe.toFixed(2)}`;
}
