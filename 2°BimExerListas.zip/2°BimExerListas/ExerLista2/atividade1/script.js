function calcularReajuste() {
    let valorInput = document.querySelector("#valorAtual"); 
    let valor = parseFloat(valorInput.value);

    if (isNaN(valor) || valor <= 0) {
        alert("Por favor, insira um valor válido para o dólar.");
        return;
    }

    let reajuste1 = valor * 1.01;
    let reajuste2 = valor * 1.02;
    let reajuste3 = valor * 1.05;
    let reajuste4 = valor * 1.10;

    document.querySelector("#reajuste1").value = reajuste1.toFixed(2);
    document.querySelector("#reajuste2").value = reajuste2.toFixed(2);
    document.querySelector("#reajuste3").value = reajuste3.toFixed(2);
    document.querySelector("#reajuste4").value = reajuste4.toFixed(2);
}

let botao = document.querySelector("#calcular");
botao.addEventListener("click", calcularReajuste);
