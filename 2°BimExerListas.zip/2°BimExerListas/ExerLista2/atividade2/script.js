function calcularIngredientes() {
    let input = document.querySelector("#numeroDePessoas");
    let pessoas = parseInt(input.value);

    if (isNaN(pessoas) || pessoas <= 0) {
        alert("Digite um número válido de pessoas.");
        return;
    }

    let ovos = pessoas * 2;
    let queijo = pessoas * 50;

    document.querySelector("#resultadoOvos").textContent = ovos + " ovos";
    document.querySelector("#resultadoQueijo").textContent = queijo + " gramas de queijo";
}

let botao = document.querySelector("#calcularIngredientes");
botao.addEventListener("click", calcularIngredientes);
