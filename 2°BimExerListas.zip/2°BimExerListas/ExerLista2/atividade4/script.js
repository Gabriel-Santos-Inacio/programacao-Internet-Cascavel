document.getElementById('pedidoForm').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const sabores = [
      document.getElementById('sabor1').value.trim(),
      document.getElementById('sabor2').value.trim(),
      document.getElementById('sabor3').value.trim(),
      document.getElementById('sabor4').value.trim()
    ];
  
    const qtdRefri = parseInt(document.getElementById('qtdRefri').value, 10);
  
    const resultadoDiv = document.getElementById('resultado');
  
    if (sabores.some(sabor => sabor === '')) {
      resultadoDiv.textContent = 'Por favor, preencha os 4 sabores de pizza.';
      return;
    }
  
    if (isNaN(qtdRefri) || qtdRefri < 0) {
      resultadoDiv.textContent = 'Informe uma quantidade válida de refrigerantes.';
      return;
    }
  
    const precoPizza = 12;
    const precoRefri = 7;
  
    const total = (precoPizza * sabores.length) + (precoRefri * qtdRefri);
  
    resultadoDiv.innerHTML = 
      `Sabores escolhidos: <b>${sabores.join(', ')}</b><br>` +
      `Quantidade de refrigerantes: <b>${qtdRefri}</b><br>` +
      `Valor total a pagar: <b>R$ ${total.toFixed(2)}</b>`;
  });
  