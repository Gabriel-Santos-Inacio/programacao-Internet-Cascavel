document.getElementById('btnCalcular').addEventListener('click', function() {
    const num1 = parseInt(document.getElementById('num1').value, 10);
    const num2 = parseInt(document.getElementById('num2').value, 10);
    const resultadosDiv = document.getElementById('resultados');
    resultadosDiv.innerHTML = '';
  
    if (isNaN(num1) || isNaN(num2)) {
      resultadosDiv.textContent = 'Por favor, insira dois números inteiros válidos.';
      return;
    }
  
    const soma = num1 + num2;
    const subtracao = num1 - num2;
    const multiplicacao = num1 * num2;
    const divisao = num2 !== 0 ? (num1 / num2) : 'Divisão por zero não permitida';
  
    resultadosDiv.innerHTML =
      'Soma: ' + soma + '<br>' +
      'Subtração: ' + subtracao + '<br>' +
      'Multiplicação: ' + multiplicacao + '<br>' +
      'Divisão: ' + divisao;
  });
  