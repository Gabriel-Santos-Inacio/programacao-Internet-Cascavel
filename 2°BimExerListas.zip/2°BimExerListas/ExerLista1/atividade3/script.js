const botaozudo = document.querySelector("#botaozudo");
const texto = document.querySelector("#valor2");
const salario = document.querySelector("#valorSemReajuste");
const porcentagem = 1;


function calcular(){
    let resultado = Number(salario.value) + (Number (salario.value) * (porcentagem / 100));
    console.log(resultado);
    texto.textContent = "Valor reajustado em 1%: " + resultado;
}

botaozudo.onclick = function () {
    calcular()
}