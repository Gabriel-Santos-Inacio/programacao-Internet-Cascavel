let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let valor3 = document.querySelector("#valor3");
let btresolucao = document.querySelector("#btresolucao");

let resultadoA = document.querySelector("#resultadoA");

function media(){
   let vlr1 = Number(valor1.value);
   let vlr2 = Number(valor2.value);
   let vlr3 = Number(valor3.value);

    let mediaAritmetica = (vlr1+vlr2+vlr3)/3;

    let mediaPonderada = (vlr1 * 3 + vlr2 * 2 + vlr3 * 5 ) / (3 + 2 + 5);

    let somaMedias = mediaAritmetica + mediaPonderada;

    let mediaDasMedias = somaMedias / 2;

    resultadoA.textContent = "a) Media Aritimetica: "+mediaAritmetica+"  |  b) Media Ponderada: "+mediaPonderada+ "  | c) Soma das Medias: "+somaMedias+ "   |  d) Media das Medias: "+mediaDasMedias;
}

btresolucao.onclick = function(){
    media()
}



